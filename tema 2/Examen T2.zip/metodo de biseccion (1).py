def biseccion(f, a, b, tol=1e-5, max_iter=100):
    """
    Encuentra la raíz de una función usando el método de bisección.
    """
    # 1. Validación de seguridad inicial
    if f(a) * f(b) >= 0:
        print("Error: El intervalo no garantiza una raíz (f(a) y f(b) tienen el mismo signo).")
        return None

    # 2. Bucle principal con límite de iteraciones (evita ciclos infinitos)
    for i in range(max_iter):
        c = (a + b) / 2.0  # Calcular punto medio
        
        # 3. Condición de éxito: Si estamos lo suficientemente cerca del cero
        if abs(f(c)) < tol or (b - a) / 2.0 < tol:
            print(f"Bisección -> Raíz encontrada en iteración {i+1}: {c}")
            return c
            
        # 4. Decisión de reemplazo
        if f(a) * f(c) < 0:
            b = c  # La raíz está en la mitad izquierda
        else:
            a = c  # La raíz está en la mitad derecha
            
    print("Error: Se alcanzó el límite máximo de iteraciones sin converger.")
    return None

# --- Zona de Prueba ---
if __name__ == "__main__":
    # Definimos la función usando una función anónima (lambda)
    funcion = lambda x: x**2 - 9
    
    # Ejecutamos el algoritmo
    biseccion(funcion, a=0, b=5)