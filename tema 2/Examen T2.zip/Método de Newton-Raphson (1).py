def newton_raphson(f, df, x0, tol=1e-5, max_iter=100):
    """
    Encuentra la raíz de una función usando el método de Newton-Raphson.
    Requiere la función original y su derivada.
    """
    x = x0
    
    # 1. Bucle principal con límite de iteraciones
    for i in range(max_iter):
        derivada = df(x)
        
        # 2. Excepción crítica: Evitar división por cero
        if derivada == 0:
            print("Error crítico: La derivada es 0. División por cero evitada.")
            return None
            
        # 3. Fórmula principal de Newton-Raphson
        x_nuevo = x - (f(x) / derivada)
        
        # 4. Condición de éxito: El "salto" entre el viejo y nuevo X es casi nulo
        if abs(x_nuevo - x) < tol:
            print(f"Newton-Raphson -> Raíz encontrada en iteración {i+1}: {x_nuevo}")
            return x_nuevo
            
        # 5. Actualizar la variable para la siguiente iteración
        x = x_nuevo
        
    print("Error: El método no convergió tras el límite de iteraciones.")
    return None

# --- Zona de Prueba ---
if __name__ == "__main__":
    # Función original
    funcion = lambda x: x**2 - 9
    # Derivada de la función original
    derivada_funcion = lambda x: 2 * x
    
    # Ejecutamos el algoritmo con un valor inicial de 5
    newton_raphson(f=funcion, df=derivada_funcion, x0=5)