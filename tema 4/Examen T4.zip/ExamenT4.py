import numpy as np

def trapecio_compuesto(f, a, b, n):
    """
    Aproxima la integral de f(x) en el intervalo [a, b] usando Trapecio Compuesto.
    """
    # Calcular el ancho de cada subintervalo
    h = (b - a) / n
    
    # Generar los puntos x desde 'a' hasta 'b'
    x = np.linspace(a, b, n + 1)
    y = f(x)
    
    # Aplicar la fórmula: h/2 * (f(a) + 2*Suma(f(x_i)) + f(b))
    suma_interior = np.sum(y[1:-1])
    integral = (h / 2) * (y[0] + 2 * suma_interior + y[-1])
    
    return integral

# Ejemplo de uso:
if __name__ == "__main__":
    # Función a integrar: f(x) = x^2
    # Integral analítica de 0 a 1 de x^2 dx = 1/3 ≈ 0.333333
    f = lambda x: x**2
    a, b = 0, 1
    n = 50  # Número de trapecios
    
    resultado = trapecio_compuesto(f, a, b, n)
    print("--- MÉTODO DEL TRAPECIO COMPUESTO ---")
    print(f"Resultado aproximado de la integral: {resultado:.6f}")