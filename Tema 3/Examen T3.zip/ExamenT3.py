import numpy as np

def gauss_jordan(A, b):
    """
    Resuelve el sistema Ax = b mediante el método de eliminación de Gauss-Jordan.
    """
    n = len(b)
    # Crear la matriz aumentada uniendo A y b en flotantes
    M = np.hstack([A.astype(float), b.astype(float).reshape(-1, 1)])
    
    for i in range(n):
        # 1. Pivoteo parcial para estabilidad numérica
        max_row = np.argmax(np.abs(M[i:n, i])) + i
        if M[max_row, i] == 0:
            raise ValueError("El sistema no tiene solución única (matriz singular).")
        
        # Intercambiar filas si es necesario
        if max_row != i:
            M[[i, max_row]] = M[[max_row, i]]
        
        # 2. Normalizar la fila del pivote actual (hacer la diagonal = 1)
        M[i] = M[i] / M[i, i]
        
        # 3. Hacer cero todos los demás elementos de la columna i
        for j in range(n):
            if i != j:
                factor = M[j, i]
                M[j] -= factor * M[i]
                
    # La última columna es el vector solución final
    return M[:, -1]

# Ejemplo de uso:
if __name__ == "__main__":
    # Sistema: 
    # 3x + 2y - z = 1
    # 2x - 2y + 4z = -2
    # -x + 0.5y - z = 0
    A = np.array([[3, 2, -1], [2, -2, 4], [-1, 0.5, -1]])
    b = np.array([1, -2, 0])
    
    solucion = gauss_jordan(A, b)
    print("--- MÉTODO DE GAUSS-JORDAN ---")
    print(f"Solución del sistema: {solucion}")